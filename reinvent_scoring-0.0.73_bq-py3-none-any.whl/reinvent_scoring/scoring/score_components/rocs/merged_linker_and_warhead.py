from rdkit import Chem
from rdkit.Chem.rdchem import RWMol
import os

from rdkit.Chem.rdchem import Mol, BondType, RWMol

from rdkit.Chem.rdmolops import SanitizeMol, CombineMols
from rdkit.Chem import RenumberAtoms
from rdkit.Chem.rdmolops import SanitizeMol
from rdkit.Chem.rdchem import AtomKekulizeException
# from openbabel import openbabel
import shutil


def get_linker_pose(rocs_sdf_file):
    """
    rocs_sdf: After rocs generate poses,
    warhead_sdf_tpl: A list, contain reference warhead files
    """
    rocs_mol = Chem.SDMolSupplier(rocs_sdf_file, sanitize=False)
    frag_list = {}
    # print(len(rocs_mol))
    for idx, mol in enumerate(rocs_mol):
        # print(idx)
        # print(Chem.MolToSmiles(mol))
        attachment_atom_list = []

        if mol is None:
            continue

        elif len(mol.GetAtoms()) == 0:
            continue

        else:
            for atom in mol.GetAtoms():

                if atom.GetIsotope() != 0:
                    neighs = atom.GetNeighbors()
                    for neigh in neighs:
                        if neigh.GetIsotope() != 0 and neigh.GetIdx() > atom.GetIdx():
                            attachment_atom_list.append((atom.GetIdx(), neigh.GetIdx()))
                            # print(atom.GetIdx(), neigh.GetIdx())
            # RW_obj = RWMol(mol)
            bond_idx = []
            for atom1_idx, atom2_idx in attachment_atom_list:
                # print(atom1_idx, atom2_idx)
                # RW_obj.RemoveBond(atom1_idx, atom2_idx)
                bond_idx.append(mol.GetBondBetweenAtoms(atom1_idx, atom2_idx).GetIdx())

            if len(bond_idx) != 2:
                continue
            res = Chem.FragmentOnBonds(mol, bond_idx, addDummies=False)
            try:
                frags = Chem.GetMolFrags(res, asMols=True, sanitizeFrags=False)
                for frag in frags:
                    iso_list = [atom.GetIsotope() for atom in frag.GetAtoms() if atom.GetIsotope() != 0]
                    if len(iso_list) == 2:
                        # print(Chem.MolToSmiles(frag))
                        # frag_list.append(frag)
                        frag_list[idx] = frag
            except AtomKekulizeException as e:
                print(idx, e)
                continue
    return frag_list

# def get_linker_pose(rocs_sdf_file):
#     """
#     rocs_sdf: After rocs generate poses,
#     warhead_sdf_tpl: A list, contain reference warhead files
#     """
#     rocs_mol = Chem.SDMolSupplier(rocs_sdf_file)
#     frag_list = []
#     # print(len(rocs_mol))
#     for idx, mol in enumerate(rocs_mol):
#         # print(idx)
#         # print(Chem.MolToSmiles(mol))
#         attachment_atom_list = []
#
#         if mol is None:
#             continue
#
#         elif len(mol.GetAtoms()) == 0:
#             continue
#
#         else:
#             for atom in mol.GetAtoms():
#
#                 if atom.GetIsotope() != 0:
#                     neighs = atom.GetNeighbors()
#                     for neigh in neighs:
#                         if neigh.GetIsotope() != 0 and neigh.GetIdx() > atom.GetIdx():
#                             attachment_atom_list.append((atom.GetIdx(), neigh.GetIdx()))
#                             # print(atom.GetIdx(), neigh.GetIdx())
#             # RW_obj = RWMol(mol)
#             bond_idx = []
#             for atom1_idx, atom2_idx in attachment_atom_list:
#                 # print(atom1_idx, atom2_idx)
#                 # RW_obj.RemoveBond(atom1_idx, atom2_idx)
#                 bond_idx.append(mol.GetBondBetweenAtoms(atom1_idx, atom2_idx).GetIdx())
#
#             if len(bond_idx) != 2:
#                 continue
#             res = Chem.FragmentOnBonds(mol, bond_idx, addDummies=False)
#             try:
#                 frags = Chem.GetMolFrags(res, asMols=True)
#                 for frag in frags:
#                     iso_list = [atom.GetIsotope() for atom in frag.GetAtoms() if atom.GetIsotope() != 0]
#                     if len(iso_list) == 2:
#                         # print(Chem.MolToSmiles(frag))
#                         frag_list.append(frag)
#             except AtomKekulizeException as e:
#                 print(idx, e)
#                 continue
#     return frag_list

def get_warhead_attachment(combined_mol):
    for atom in combined_mol.GetAtoms():
        if atom.GetSymbol() == '*':
            neigh = atom.GetNeighbors()[0]
            neigh_isotope_num = neigh.GetIsotope()
            neigh_idx = neigh.GetIdx()
            return atom.GetIdx(), neigh_idx, neigh_isotope_num

def combine_work(scaffold, decoration):
    # print(Chem.MolToSmiles(scaffold))
    # print(Chem.MolToSmiles(decoration))
    for idx, atom in enumerate(decoration.GetAtoms(), 100):
        atom.SetAtomMapNum(idx)


    combined_scaffold = RWMol(CombineMols(scaffold, decoration))
    # print(Chem.MolToSmiles(combined_scaffold))

    # neigh_idx = None
    atom_idx = None
    # neigh_isotope_num = None

    warhead_atom_idx, neigh_idx, neigh_isotope_num = get_warhead_attachment(combined_scaffold)

    # for atom in combined_scaffold.GetAtoms():
    #     if atom.GetIsotope() not in [0, neigh_isotope_num]:
    #         atom_idx = atom.GetIdx()
    #         break
    
    
    for atom in combined_scaffold.GetAtoms():
        if atom.GetIsotope() == neigh_isotope_num:
            atom_idx = atom.GetIdx()
            break
    

    if neigh_idx is not None and atom_idx is not None:

        bond_type = BondType.SINGLE

        combined_scaffold.AddBond(neigh_idx, atom_idx, bond_type)
        # print(Chem.MolToSmiles(combined_scaffold))
        combined_scaffold.RemoveAtom(warhead_atom_idx)
        # print(Chem.MolToSmiles(combined_scaffold))
        # print('Done')
        combined_scaffold = combined_scaffold.GetMol()
        return combined_scaffold

def reorder_warheads(combine_molecules):
    atommap_idx_list = []
    no_atommap_idx_list = []
    for atom in combine_molecules.GetAtoms():
        if atom.GetAtomMapNum() >=100:
            atommap_idx_list.append(atom.GetIdx())
        else:
            no_atommap_idx_list.append(atom.GetIdx())

    reorder_idx = atommap_idx_list + no_atommap_idx_list
    reorder_molecule = RenumberAtoms(combine_molecules, reorder_idx)

    return reorder_molecule



def combine_linker_and_warheads(frag_list, warhead_sdf_tpl, rearrange_sdf):
    warhead1 = Chem.MolFromMolFile(warhead_sdf_tpl[0])
    warhead2 = Chem.MolFromMolFile(warhead_sdf_tpl[1])
    # warhead_list = [warhead1, warhead2]

    # for i in range(0,len(frag_list)):
    #     linker_one = combine(warhead1, linker[i])
    #     liner_two = combine(linker_one, warhead2)

    # with Chem.SDWriter(rearrange_sdf) as w:
    w = Chem.SDWriter(rearrange_sdf)
    for idx, frag in frag_list.items():
        # print(idx)
        # print(Chem.MolToSmiles(frag))
        combine_1 = combine_work(frag, warhead1)
        whole_molecule = combine_work(combine_1, warhead2)
        reorder_molecule = reorder_warheads(whole_molecule)
        # for atom in reorder_molecule.GetAtoms():
        #     atom.SetIsotope(0)
        # print(Chem.MolToSmiles(reorder_molecule))
        try:
            SanitizeMol(reorder_molecule)

            reorder_molecule.SetProp('_Name', str(idx))
            w.write(reorder_molecule)
        except ValueError:
            print('Error molecule', idx)
            continue
    w.close()
    print('Rearranged molecules generated')

# def combine_linker_and_warheads(frag_list, warhead_sdf_tpl, rearrange_sdf):
#     warhead1 = Chem.MolFromMolFile(warhead_sdf_tpl[0])
#     warhead2 = Chem.MolFromMolFile(warhead_sdf_tpl[1])
#     # warhead_list = [warhead1, warhead2]
#
#     # for i in range(0,len(frag_list)):
#     #     linker_one = combine(warhead1, linker[i])
#     #     liner_two = combine(linker_one, warhead2)
#
#     # with Chem.SDWriter(rearrange_sdf) as w:
#     w = Chem.SDWriter(rearrange_sdf)
#     for idx, frag in enumerate(frag_list):
#         # print(idx)
#         # print(Chem.MolToSmiles(frag))
#         combine_1 = combine_work(frag, warhead1)
#         whole_molecule = combine_work(combine_1, warhead2)
#         reorder_molecule = reorder_warheads(whole_molecule)
#         # for atom in reorder_molecule.GetAtoms():
#         #     atom.SetIsotope(0)
#         # print(Chem.MolToSmiles(reorder_molecule))
#         try:
#             SanitizeMol(reorder_molecule)
#             w.write(reorder_molecule)
#         except ValueError:
#             print('Error molecule', idx)
#             continue
#     w.close()
#     print('Rearranged molecules generated')


### openbabel=2.4.1
# def minimization_with_constrain(rearranged_sdf, rearranged_h_sdf, rearranged_h_mae, rearranged_h_mini_mae, rearranged_h_mini_sdf, rearranged_h_mini_sdf_docking, minimization_config):
#
#     ### Add H
#     output = pybel.Outputfile('sdf', rearranged_h_sdf, overwrite=True)
#     for mol in pybel.readfile('sdf', rearranged_sdf):
#         # print(len(mol.atoms))
#         mol.addh()
#         # print(len(mol.atoms))
#         output.write(mol)
#     output.close()
#
#     ### SDF convert to MAE
#     cmd_sdf2mae = 'structconvert -isd ' + rearranged_h_sdf + ' -omae ' + rearranged_h_mae
#     # print(cmd_sdf2mae)
#     os.system(cmd_sdf2mae)
#
#     ### minimization with constrain: generated rearranged_h_mini.mae
#     work_dir, filename = os.path.split(rearranged_h_mae)
#     os.chdir(work_dir)
#     os.system('macromodel ' + minimization_config + ' -WAIT')
#
#     ### minimized MAE convert to SDF
#     cmd_mae2sdf = 'structconvert -imae ' + rearranged_h_mini_mae + ' -osd ' + rearranged_h_mini_sdf
#     os.system(cmd_mae2sdf)
#
#     ### copy the minimization_sdf_epochs to rearranged_h_mini.sdf for next docking
#     shutil.copy(rearranged_h_mini_sdf, rearranged_h_mini_sdf_docking)

### openbabel=3.1.1

def add_atommap(rearranged_sdf, rearranged_h_temp, rearranged_h_sdf):
    ori_sdf_mols = Chem.SDMolSupplier(rearranged_sdf)
    h_sdf_mols = Chem.SDMolSupplier(rearranged_h_temp, removeHs=False)

    # for mol in h_sdf_mols:
    #     for atom in mol.GetAtoms():
    #         print(atom.GetSymbol())

    w = Chem.SDWriter(rearranged_h_sdf)
    for ori_mol, h_mol in zip(ori_sdf_mols, h_sdf_mols):
        ori_atoms = ori_mol.GetAtoms()
        h_atoms = h_mol.GetAtoms()
        for ori_atom, h_atom in zip(ori_atoms, h_atoms):
            # print(ori_atom.GetSymbol(), h_atom.GetSymbol())
            h_atom.SetAtomMapNum(ori_atom.GetAtomMapNum())
        w.write(h_mol)
    w.close()
    
    
    
    
            

def minimization_with_constrain(rearranged_sdf, rearranged_h_temp, rearranged_h_sdf, rearranged_h_mae, rearranged_h_mini_mae,
                                rearranged_h_mini_sdf, rearranged_h_mini_sdf_docking, minimization_config):
    ### Add H
    # output = pybel.Outputfile('sdf', rearranged_h_sdf, overwrite=True)
    # for mol in pybel.readfile('sdf', rearranged_sdf):
    #     # print(len(mol.atoms))
    #     mol.addh()
    #     # print(len(mol.atoms))
    #     output.write(mol)
    # output.close()

    ### Add H
    # obConversion = openbabel.OBConversion()
    # obConversion.OpenInAndOutFiles(rearranged_sdf, rearranged_h_sdf)
    # obConversion.SetInAndOutFormats('mdl', 'mdl')
    # mol = openbabel.OBMol()
    # mol.AddHydrogens()
    # obConversion.ReadFile(mol, rearranged_sdf)
    # obConversion.Convert()
    # # obConversion.WriteFile(mol, rearranged_h_sdf)
    # obConversion.CloseOutFile()

    ### Add h
    cmd_add_h = '/home/baiqing/anaconda3/envs/DockStream/bin/obabel -isdf ' + rearranged_sdf + ' -osdf -O ' + rearranged_h_temp + ' -h'
    print(cmd_add_h)
    os.system(cmd_add_h)
    
    ### need add atommap, because when openbabel process molecules, remove the atommap
    add_atommap(rearranged_sdf, rearranged_h_temp, rearranged_h_sdf)

    ### SDF convert to MAE
    cmd_sdf2mae = 'structconvert -isd ' + rearranged_h_sdf + ' -omae ' + rearranged_h_mae
    # print(cmd_sdf2mae)
    os.system(cmd_sdf2mae)

    ### minimization with constrain: generated rearranged_h_mini.mae
    work_dir, filename = os.path.split(rearranged_h_mae)
    os.chdir(work_dir)
    os.system('macromodel ' + minimization_config + ' -WAIT')
    
    ### remove tempdir "local*"
    os.system('rm -rf local*')

    ### minimized MAE convert to SDF
    cmd_mae2sdf = 'structconvert -imae ' + rearranged_h_mini_mae + ' -osd ' + rearranged_h_mini_sdf
    os.system(cmd_mae2sdf)

    ### copy the minimization_sdf_epochs to rearranged_h_mini.sdf for next docking
    shutil.copy(rearranged_h_mini_sdf, rearranged_h_mini_sdf_docking)



if __name__ == '__main__':
    base_dir = '/data/baiqing/PycharmProjects/Reinvent-master-3.2/my_script'
    warhead1 = os.path.join(base_dir, 'warhead1_last_isotope.sdf')
    warhead2 = os.path.join(base_dir, 'warhead2_last_isotope.sdf')
    rocs_sdf_file = '/data/baiqing/PycharmProjects/Reinvent-master-3.2/result/LINK_invent/BRD9/temp_test/dock.sdf'

    # frag_list = get_linker_pose(rocs_sdf_file)

    workdir = '/data/baiqing/PycharmProjects/Reinvent-master-3.2/result/LINK_invent/BRD9/temp_test'
    rearranged_sdf = os.path.join(workdir, 'rearranged.sdf')
    rearranged_h_sdf = os.path.join(workdir, 'rearranged_h_0000.sdf')
    new_rearranged_h_sdf = os.path.join(workdir, 'new_rearranged_h_0000.sdf')
    
    rearranged_h_mae = os.path.join(base_dir, 'rearranged_h.mae')
    rearranged_h_mini_mae = os.path.join(base_dir, 'rearranged_h_mini.mae')
    rearranged_h_mini_sdf = os.path.join(base_dir, 'rearranged_h_mini.sdf')

    add_atommap(rearranged_sdf, rearranged_h_sdf, new_rearranged_h_sdf)




    # combine_linker_and_warheads(frag_list, (warhead1, warhead2), rearranged_sdf)

    # cmd = 'obabel -isdf ' + redocked_sdf + ' -osdf -O ' + redocked_h_sdf + ' -h'
    # import pybel
    # for mol in pybel.readfile('sdf', redocked_sdf):
    #     print(mol.molwt)

    # minimization_with_constrain(rearranged_sdf, rearranged_h_sdf, rearranged_h_mae, rearranged_h_mini_mae, rearranged_h_mini_sdf)









import os
from rdkit import Chem


def write_config(rearranged_h_mae, rearranged_h_mini_mae, config_path):
    w = open(config_path, 'w')
    w.write('INPUT_STRUCTURE_FILE  ' + rearranged_h_mae + '\n')
    w.write('CONFSEARCH_METHOD mcmm\n')
    w.write('FORCE_FIELD OPLS_2005\n')
    w.write('SOLVENT Water\n')
    w.write('DIELECTRIC_CONSTANT 1.0\n')
    w.write('CHARGES_FROM Force field\n')
    w.write('CUTOFF None\n')
    w.write('MINI_METHOD PRCG\n')
    w.write('OUTCONFS_PER_SEARCH 1\n')
    w.write('CONFSEARCH_STEPS 200\n')
    w.write('MAXIMUM_ITERATION 200\n')
    w.write('CONVERGE_ON Gradient\n')
    w.write('CONVERGENCE_THRESHOLD 0.05\n')
    w.write('ENERGY_WINDOW 5.0\n')
    w.write('CONFSEARCH_STEPS_PER_ROTATABLE 50\n')
    w.write('ELECTROSTATIC_TREATMENT Constant dielectric\n')
    w.write('JOB_TYPE MINIMIZATION\n')
    w.write('OUTPUT_STRUCTURE_FILE ' + rearranged_h_mini_mae + '\n')
    w.write('USE_SUBSTRUCTURE_FILE True')
    w.close()


def write_sbc(warhead1_file, warhead2_file, sbc_file):
    warhead1_mol = Chem.MolFromMolFile(warhead1_file)
    warhead2_mol = Chem.MolFromMolFile(warhead2_file)

    atom_number = len(warhead1_mol.GetAtoms()) + len(warhead2_mol.GetAtoms()) - 2  ### -2 mean minus 2 *
    # print(atom_number)

    sbc_file = open(sbc_file, 'w')
    line_list = []
    for atom_idx in range(1, atom_number + 1):
        line = ' FXAT      ' + str(atom_idx) + '      0      0      0   100.0000     0.0000     0.0000     0.0000\n'
        line_list.append(line)
    sbc_file.writelines(line_list)
    sbc_file.close()


if __name__ == '__main__':
    base_dir = '/data/baiqing/PycharmProjects/Reinvent-master-3.2/my_script'
    warhead1 = os.path.join(base_dir, 'warhead1_last_isotope.sdf')
    warhead2 = os.path.join(base_dir, 'warhead2_last_isotope.sdf')

    sbc = os.path.join(base_dir, 'minimization_config', 'rearranged_h.sbc')

    write_sbc(warhead1, warhead2, sbc)

    # input_conf = os.path.join(base_dir, 'minimization_config', 'input_file.conf')
    # os.chdir(os.path.join(base_dir, 'minimization_config'))
    # os.system('macromodel input_file.conf -NOJOBID')

    print('Done')